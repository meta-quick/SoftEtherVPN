void DllMainCRTStartup()
{
}

void PenKawaKuwaKuwa()
{
}

