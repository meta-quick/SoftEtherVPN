// SoftEther VPN Source Code - Developer Edition Master Branch
// Cedar Communication Module


// NM.h
// Header of NM.c

#ifndef	NM_H
#define	NM_H

// External function
void NMExec();

#endif	// NM_H


